﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG_212_Project1_434963985
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void orderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //creating instance of form 1
            MenuForm menuForm = new MenuForm();
            menuForm.MdiParent = this;
            menuForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //exitting application
            Application.Exit();
        }

        private void adminLoginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //creating instance of login form
            Login login = new Login();
            login.MdiParent = this;
            login.Show();
        }
    }
}
