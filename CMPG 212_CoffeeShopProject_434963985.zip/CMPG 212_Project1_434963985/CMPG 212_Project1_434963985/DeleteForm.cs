﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_212_Project1_434963985
{
    public partial class DeleteForm : Form
    {
        //declaring variables
        SqlConnection conn;
        SqlCommand command;
        SqlDataAdapter dataAdapter;

        //creating instance of main form 
        MenuForm main = new MenuForm();

        public DeleteForm()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //resetting all choices
            comboBox1.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
            comboBox1.Focus();
        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {
            

            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //exception handling
            try
            {
                comboBox1.SelectedIndex = -1;
                conn = new SqlConnection(main.connectionstring);

                if (comboBox1.SelectedIndex == 1)
                {
                    string sql = "SELECT * Drink FROM Coffee";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Coffee");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Coffee";
                    conn.Close();

                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    string sql = "SELECT * Dessert FROM Desserts";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Desserts");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Desserts";
                    conn.Close();
                }
                else if (comboBox1.SelectedIndex == 3)
                {
                    string sql = "SELECT * Sandwich FROM Sandwiches";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Sandwiches");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Sandwiches";
                    conn.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
