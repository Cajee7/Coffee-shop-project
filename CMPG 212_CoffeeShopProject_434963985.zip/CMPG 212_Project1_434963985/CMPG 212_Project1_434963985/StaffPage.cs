﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_212_Project1_434963985
{
    public partial class StaffPage : Form
    {
        //declaring variables
        SqlConnection conn;
        SqlCommand command;
        SqlDataAdapter dataAdapter;
        SqlDataReader dataReader;

        //creating instance of main form
        MenuForm main = new MenuForm();

        public StaffPage()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //exception handling
            try
            {
                //connecting to database
                conn = new SqlConnection(main.connectionstring);

                //sql statements to get data from tables
                string sql = "SELECT * FROM Coffee";
                
                

                //populating gridview
                conn.Open();
                command = new SqlCommand(sql, conn);
                dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = command;
                DataSet ds = new DataSet();
                dataAdapter.Fill(ds, "Coffee");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Coffee";
                conn.Close();        
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDesserts_Click(object sender, EventArgs e)
        {
            string sql2 = "SELECT * FROM Desserts";

            conn.Open();
            command = new SqlCommand(sql2, conn);
            dataAdapter = new SqlDataAdapter();
            dataAdapter.SelectCommand = command;
            DataSet ds2 = new DataSet();
            dataAdapter.Fill(ds2, "Desserts");
            dataGridView1.DataSource = ds2;
            dataGridView1.DataMember = "Desserts";
            conn.Close();
        }

        private void btnSandwiches_Click(object sender, EventArgs e)
        {
            string sql3 = "SELECT * FROM Sandwiches";

            conn.Open();
            command = new SqlCommand(sql3, conn);
            dataAdapter = new SqlDataAdapter();
            dataAdapter.SelectCommand = command;
            DataSet ds3 = new DataSet();
            dataAdapter.Fill(ds3, "Sandwiches");
            dataGridView1.DataSource = ds3;
            dataGridView1.DataMember = "Sandwiches";
            conn.Close();
        }

        private void StaffPage_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //exception handling
            try
            {
                //creating instance of form
                AddItem addItem = new AddItem();
                addItem.ShowDialog();

                conn = new SqlConnection(main.connectionstring);


                //checking which table to add values in
                if (addItem.comboBox1.SelectedIndex == 1)
                {
                    string sql = $"INSERT INTO Coffee(Drink, Price, Quantity)VALUES('{addItem.txtName.Text}', '{addItem.txtPrice.Text}', '{addItem.txtQuantity.Text}' )";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }
                else if (addItem.comboBox1.SelectedIndex == 2)
                {
                    string sql = $"INSERT INTO Desserts(Dessert, Price, Quantity)VALUES('{addItem.txtName.Text}', '{addItem.txtPrice.Text}', '{addItem.txtQuantity.Text}' )";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }
                else if (addItem.comboBox1.SelectedIndex == 3)
                {
                    string sql = $"INSERT INTO Sandwiches(Sandwich, Price, Quantity)VALUES('{addItem.txtName.Text}', '{addItem.txtPrice.Text}', '{addItem.txtQuantity.Text}' )";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }

                dataAdapter = new SqlDataAdapter();
                dataAdapter.InsertCommand = command;
                dataAdapter.InsertCommand.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Item added successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //exception handling
            try
            {
                //creating instance of form
                DeleteForm delete = new DeleteForm();
                delete.ShowDialog();

                conn = new SqlConnection(main.connectionstring);


                //checking which table to delete values in
                if (delete.comboBox1.SelectedIndex == 1)
                {
                    string sql = $"DELETE FROM Coffee WHERE Drink  = '" + delete.txtName.Text + "'";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }
                else if (delete.comboBox1.SelectedIndex == 2)
                {
                    string sql = $"DELETE FROM Desserts WHERE Dessert  = '" + delete.txtName.Text + "'";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }
                else if (delete.comboBox1.SelectedIndex == 3)
                {
                    string sql = $"DELETE FROM Sandwiches WHERE Sandwich = '" + delete.txtName.Text + "'";
                    conn.Open();
                    command = new SqlCommand(sql, conn);
                }

                dataAdapter = new SqlDataAdapter();
                dataAdapter.DeleteCommand = command;
                dataAdapter.DeleteCommand.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Item deleted successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            conn = new SqlConnection(main.connectionstring);
            conn.Open();
            //exception handling
            try
            {
                if(comboBox1.SelectedIndex == 1)
                {
                    string sql = $"SELECT Drink, Price, Quantity FROM Coffee WHERE Drink LIKE '%" + txtSearch.Text
                        + "%' OR Price LIKE '%" + txtSearch.Text + "%' OR Quantity LIKE '%" + txtSearch.Text + "%'";

                   
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Coffee");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Coffee";
                    
                }
                else if(comboBox1.SelectedIndex == 2)
                {
                    string sql = $"SELECT Dessert, Price, Quantity FROM Desserts WHERE Dessert LIKE '%" + txtSearch.Text
                        + "%' OR Price LIKE '%" + txtSearch.Text + "%' OR Quantity LIKE '%" + txtSearch.Text + "%'";

                    
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Desserts");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Desserts";
                    
                }
                else if(comboBox1.SelectedIndex == 3)
                {
                    string sql = $"SELECT Sandwich, Price, Quantity FROM Sandwiches WHERE Sandwich LIKE '%" + txtSearch.Text
                        + "%' OR Price LIKE '%" + txtSearch.Text + "%' OR Quantity LIKE '%" + txtSearch.Text + "%'";

                   
                    command = new SqlCommand(sql, conn);
                    dataAdapter = new SqlDataAdapter();
                    dataAdapter.SelectCommand = command;
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds, "Sandwiches");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Sandwiches";
                    
                }
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
