﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG_212_Project1_434963985
{
    public partial class AddItem : Form
    {
        public AddItem()
        {
            InitializeComponent();
        }

        private void lblTable_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //resetting all choices
            comboBox1.SelectedIndex = -1;
            txtName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            comboBox1.Focus();
        }

        private void AddItem_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = -1;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //closing form
            this.Close();
        }
    }
}
