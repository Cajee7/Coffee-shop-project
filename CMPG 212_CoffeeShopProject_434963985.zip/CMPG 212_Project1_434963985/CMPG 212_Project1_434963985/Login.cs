﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG_212_Project1_434963985
{
    public partial class Login : Form
    {
        //declaring variable
        String num = "123456";
        String pass = "123456";

        public Login()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //clearing textboxes
            txtStaff.Text = "";
            txtPass.Text = "";
            txtStaff.Focus();
            errorProvider1.Clear();
            errorProvider2.Clear();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //exception handling
            try
            {
                if (txtStaff.Text != num)
                {
                    errorProvider1.SetError(txtStaff , "Invalid Values");
                }
                if (txtPass.Text != pass)
                {
                    errorProvider2.SetError(txtPass , "Invalid password");
                }
                else
                {
                    this.Close();
                    //entering staff page after login
                    StaffPage staff = new StaffPage();
                    staff.ShowDialog();                   
                }
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
