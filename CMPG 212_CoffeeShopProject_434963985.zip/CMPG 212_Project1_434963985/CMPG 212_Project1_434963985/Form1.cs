﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_212_Project1_434963985
{
    public partial class MenuForm : Form
    {
        //declaring variables
        SqlConnection conn;
        SqlCommand command;
        SqlDataAdapter dataAdapter;
        SqlDataReader dataReader;

        public string connectionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\OEM\Documents\CMPG 212\CMPG 212_Project1_434963985\CMPG 212_Project1_434963985\Database1.mdf;Integrated Security=True";

        public MenuForm()
        {
            InitializeComponent();
        }

        //creating a method that clears all items
        private void clear()
        {
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;

            hScrollBar1.Value = 1;
            hScrollBar2.Value = 1;
            hScrollBar3.Value = 1;

            lblOut.Text = "1";
            lblOut2.Text = "1";
            lblOut3.Text = "1";
        }

        private void listbox()
        {
            //adding listbox pre items
            lstOrder.Items.Add("Your order: ");
            lstOrder.Items.Add("***************************************");
            
            //adding to total
            lblTotal.Text = "Total: ";

        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            //displaying scroll value in label
            lblOut.Text = (hScrollBar1.Value).ToString();
        }

        private void MenuForm_Load(object sender, EventArgs e)
        {
            
            //exception handling
            try
            {
                //displaying values in combobox
                conn = new SqlConnection(connectionstring);

                string sql = "SELECT Drink, Price FROM Coffee";
                command = new SqlCommand(sql, conn);

                conn.Open();

                dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = command;

                DataSet ds = new DataSet();
                dataAdapter.Fill(ds, "Coffee");

                // Populate comboBox1 with item names and prices
                comboBox1.DisplayMember = "Drink";
                comboBox1.ValueMember = "Price";
                comboBox1.DataSource = ds.Tables["Coffee"];

                comboBox1.SelectedIndex = -1;

                conn.Close();

                
                conn.Open();
                string sql2 = "SELECT Sandwich, Price FROM Sandwiches";  // Replace "YourTable" with your actual table name
                command = new SqlCommand(sql2, conn);

                dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = command;

                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);

                comboBox2.DisplayMember = "Sandwich";
                comboBox2.ValueMember = "Price";
                comboBox2.DataSource = dt;

                comboBox2.SelectedIndex = -1;

                conn.Close();


                //displaying desserts in combobox 3
                conn.Open();
                string sql3 = "SELECT Dessert, Price FROM Desserts";  // Replace "YourTable" with your actual table name
                command = new SqlCommand(sql3, conn);

                dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = command;

                DataTable dt2 = new DataTable();
                dataAdapter.Fill(dt2);

                comboBox3.DisplayMember = "Dessert";
                comboBox3.ValueMember = "Price";
                comboBox3.DataSource = dt2;

                comboBox3.SelectedIndex = -1;

                conn.Close();

                //setting up scrollbars
                hScrollBar1.Minimum = 1;
                hScrollBar1.Maximum = 10;
                hScrollBar1.LargeChange = 1;
                hScrollBar1.SmallChange = 1;

                hScrollBar2.Minimum = 1;
                hScrollBar2.Maximum = 10;
                hScrollBar2.LargeChange = 1;
                hScrollBar2.SmallChange = 1;

                hScrollBar3.Maximum = 10;
                hScrollBar3.Minimum = 1;
                hScrollBar3.LargeChange = 1;
                hScrollBar3.SmallChange = 1;

                lblOut.Text = "1";
                lblOut2.Text = "1";
                lblOut3.Text = "1";

                listbox();

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            //displaying scroll value in label
            lblOut2.Text = (hScrollBar2.Value).ToString();
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            lblOut3.Text = (hScrollBar3.Value).ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                string selectedName = comboBox1.Text;
                decimal selectedPrice = (decimal)comboBox1.SelectedValue;
                int quantity = hScrollBar1.Value;
                decimal totalPrice = selectedPrice * quantity;
                string item = $"{quantity} - {selectedName} for R{selectedPrice} = R{totalPrice.ToString("0.00")}";

                lstOrder.Items.Add(item);
            }
            if (comboBox2.SelectedIndex != -1)
            {
                string itemName = comboBox2.Text;
                decimal itemPrice = Convert.ToDecimal(comboBox2.SelectedValue);
                int quantity = hScrollBar2.Value;

                decimal totalPrice = itemPrice * quantity;

                string item = $"{quantity} - {itemName} for R{itemPrice} = R{totalPrice.ToString("0.00")}";

                lstOrder.Items.Add(item);
            }
            if (comboBox3.SelectedIndex != -1)
            {
                string itemName = comboBox3.Text;
                decimal itemPrice = Convert.ToDecimal(comboBox3.SelectedValue);
                int quantity = hScrollBar3.Value;

                decimal totalPrice = itemPrice * quantity;

                string item = $"{quantity} - {itemName} for R{itemPrice} = R{totalPrice.ToString("0.00")}";

                lstOrder.Items.Add(item);
            }

            //clearing all selections
            clear();

             // Calculate the total cost of items in lstOrder
             decimal totalCost = 0;
            for (int i = 0; i < lstOrder.Items.Count; i++)
            {
                string item = lstOrder.Items[i].ToString();
                int index = item.LastIndexOf("R");
                 if (index != -1)
                 {
                    string priceString = item.Substring(index + 1);
                    decimal price = decimal.Parse(priceString);
                    totalCost += price;
                 }
            }

              // Display the total cost in lblTotal
              lblTotal.Text = $"Total: R{totalCost.ToString("0.00")}";

        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            //creating instance of new form
            Receipt receiptForm = new Receipt();

            // Copy the items from lstOrder to lstReceipt
            decimal total = 0;
            for (int i = 0; i < lstOrder.Items.Count; i++)
            {
                string item = lstOrder.Items[i].ToString();
                receiptForm.lstReceipt.Items.Add(item);

                // Extract the price from the item string
                int priceStartIndex = item.LastIndexOf("R") + 1;
                string priceString = item.Substring(priceStartIndex);

                // Convert the price string to a decimal
                decimal price;
                if (decimal.TryParse(priceString, out price))
                {
                    // Add the price to the total
                    total += price;
                }
            }

            // Get the current date and time
            DateTime currentDateTime = DateTime.Now;

            // Add the date and time to the receipt
            string dateTimeString = "Date: " + currentDateTime.ToShortDateString() + " Time: " + currentDateTime.ToShortTimeString();
            receiptForm.lstReceipt.Items.Insert(0, dateTimeString);

            // Copy the total to lblTotal on the Receipt form
            receiptForm.lblTotal.Text = lblTotal.Text;

            // Show the Receipt form
            receiptForm.Show();

            //clearing form
            clear();
            lstOrder.Items.Clear();
            lblTotal.Text = "Total: ";
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //resetting all choices
            clear();
            lstOrder.Items.Clear();
            lblTotal.Text = " ";
            listbox();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if an item is selected in the listbox
            if (lstOrder.SelectedItem != null)
            {
                // Get the selected item
                string selectedItem = lstOrder.SelectedItem.ToString();

                // Remove the selected item from the listbox
                lstOrder.Items.Remove(lstOrder.SelectedItem);

                // Extract the price from the selected item
                int index = selectedItem.LastIndexOf("R");
                if (index != -1)
                {
                    string priceString = selectedItem.Substring(index + 1);
                    decimal price = decimal.Parse(priceString);

                    // Subtract the price from the total cost
                    decimal currentTotal = decimal.Parse(lblTotal.Text.Substring(8));
                    decimal newTotal = currentTotal - price;

                    // Display the updated total in lblTotal
                    lblTotal.Text = $"Total: R{newTotal.ToString("0.00")}";
                }

            }
        }

        private void lstOrder_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
